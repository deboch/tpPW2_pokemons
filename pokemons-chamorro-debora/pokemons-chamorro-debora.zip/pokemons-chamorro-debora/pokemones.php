<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Pokedex-ChamorroDebora</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <link href="recursos/css/bootstrap.min.css" rel="stylesheet">
  <link href="recursos/css/mdb.min.css" rel="stylesheet">
  <link href="recursos/css/style.min.css" rel="stylesheet">
  <style type="text/css">
    /* Necessary for full page carousel*/
    html,
    body,
    header,
    .view {
      height: 100%;
    }

    /* Carousel*/
    .carousel,
    .carousel-item,
    .carousel-item.active {
      height: 100%;
    }
    .carousel-inner {
      height: 100%;
    }

    @media (min-width: 800px) and (max-width: 850px) {
      .navbar:not(.top-nav-collapse) {
          background: #1C2331!important;
      }
  }

  </style>
</head>
<body>
<?php require_once("recursos/header.php");?>
<section>
<br>
<h2 class="my-5 h3 text-center">Album Pokedex...</h2>
<div class="row features-small mt-5 wow fadeIn">

</div>
<!--First row-->
<div class="row features-small mt-5 wow fadeIn">

  <!--Grid column-->
  <div class="col-xl-3 col-lg-6 sectionAlbum">
    <!--Grid row-->
    <div class="row">
      <div class="col-2">
        <img src="recursos/img/pikachu.png">
      </div>
      <div class="col-10 mb-2 pl-3">
        <h5 class="feature-title font-bold mb-1">Pokemón 4</h5>
      </div>
    </div>
    <!--/Grid row-->
  </div>
  <!--/Grid column-->

  <!--Grid column-->
  <div class="col-xl-3 col-lg-6 sectionAlbum">
    <!--Grid row-->
    <div class="row">
      <div class="col-2">
      <img src="recursos/img/clefable.png">
      </div>
      <div class="col-10 mb-2">
        <h5 class="feature-title font-bold mb-1">Pokemon 1</h5>
      </div>
    </div>
    <!--/Grid row-->
  </div>
  <!--/Grid column-->

  <!--Grid column-->
  <div class="col-xl-3 col-lg-6 sectionAlbum">
    <!--Grid row-->
    <div class="row">
      <div class="col-2">
        <img src="recursos/img/zubat.png">
      <div class="col-10 mb-2">
        <h5 class="feature-title font-bold mb-1">Pokemón 2</h5>
      </div>
    </div>
    <!--/Grid row-->
  </div>
  <!--/Grid column-->

  <!--Grid column-->
  <div class="col-xl-3 col-lg-6 sectionAlbum">
    <!--Grid row-->
    <div class="row">
      <div class="col-2">
      <img src="recursos/img/lapras.jpg">
      </div>
      <div class="col-10 mb-2">
        <h5 class="feature-title font-bold mb-1">Pokemón 3</h5>
      </div>
    </div>
    <!--/Grid row-->
  </div>
  <!--/Grid column-->

</div>
<!--/First row-->



</section>
<?php require_once("recursos/footer.php");?>
</body>
</html>