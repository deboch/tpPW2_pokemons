
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Pokedex-ChamorroDebora</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  <link href="recursos/css/bootstrap.min.css" rel="stylesheet">
  <link href="recursos/css/mdb.min.css" rel="stylesheet">
  <link href="recursos/css/style.min.css" rel="stylesheet">
  <style type="text/css">
    /* Necessary for full page carousel*/
    html,
    body,
    header,
    .view {
      height: 100%;
    }

    /* Carousel*/
    .carousel,
    .carousel-item,
    .carousel-item.active {
      height: 100%;
    }
    .carousel-inner {
      height: 100%;
    }

    @media (min-width: 800px) and (max-width: 850px) {
      .navbar:not(.top-nav-collapse) {
          background: #1C2331!important;
      }
  }

  </style>
</head>
<body>
<?php require_once("recursos/header.php");?>

    <section class="mb-4">
        <div id="carousel-example-1z" class="carousel slide carousel-fade" data-ride="carousel">       
            <div class="carousel-inner" role="listbox">                     
                <div class="carousel-item active">
                    <img class="d-block w-100" src="recursos/img/fondo4.jpg" alt="First slide">
                </div>           
            </div>                  
        </div>
    </section>

<?php require_once("recursos/footer.php");?>


  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Initializations -->
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();
  </script>
</body>
</html>